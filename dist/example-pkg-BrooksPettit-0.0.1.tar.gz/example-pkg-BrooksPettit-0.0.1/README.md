# python_example_pkg
A simple example of a python package.

use:
[Github-flavored Markdown](https://guides.github.com/features/mastering-markdown/)
To write the README content.
